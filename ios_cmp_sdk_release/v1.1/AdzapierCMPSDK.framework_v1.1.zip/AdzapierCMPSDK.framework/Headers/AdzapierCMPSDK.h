//
//  AdzapierCMPSDK.h
//  AdzapierCMPSDK
//
//  Created by Devendra Shewale on 28/04/23.
//

#import <Foundation/Foundation.h>

//! Project version number for AdzapierCMPSDK.
FOUNDATION_EXPORT double AdzapierCMPSDKVersionNumber;

//! Project version string for AdzapierCMPSDK.
FOUNDATION_EXPORT const unsigned char AdzapierCMPSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdzapierCMPSDK/PublicHeader.h>


